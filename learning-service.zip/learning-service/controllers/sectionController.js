const Section = require('../models/Section');
const Problem = require('../models/Problem');

// Create Section
exports.createSection = async (req, res, next) => {
    try {
        const { title } = req.body;
        if (!title) {
            return res.status(400).json({ message: 'Title is required' });
        }

        const section = await Section.create({ title });
        res.status(201).json({ success: true, section });
    } catch (error) {
        next(error);
    }
};

// Get All Sections
exports.getAllSections = async (req, res, next) => {
    try {
        const sections = await Section.findAll();
        res.json({ success: true, sections });
    } catch (error) {
        next(error);
    }
};

// Get Section by ID
exports.getSectionById = async (req, res, next) => {
    try {
        const section = await Section.findById(req.params.id);
        if (!section) {
            return res.status(404).json({ message: 'Section not found' });
        }
        res.json({ success: true, section });
    } catch (error) {
        next(error);
    }
};

// Update Section
exports.updateSection = async (req, res, next) => {
    try {
        const { title } = req.body;
        const result = await Section.update(req.params.id, { title });
        if (result.matchedCount === 0) {
            return res.status(404).json({ message: 'Section not found' });
        }
        res.json({ success: true, message: 'Section updated successfully' });
    } catch (error) {
        next(error);
    }
};

// Delete Section
exports.deleteSection = async (req, res, next) => {
    try {
        const result = await Section.delete(req.params.id);
        if (result.deletedCount === 0) {
            return res.status(404).json({ message: 'Section not found' });
        }
        res.json({ success: true, message: 'Section deleted successfully' });
    } catch (error) {
        next(error);
    }
};

// Create Subsection
exports.addSubsection = async (req, res, next) => {
    try {
        const { title } = req.body;
        if (!title) {
            return res.status(400).json({ message: 'Subsection title is required' });
        }
        const { result, subsection } = await Section.addSubsection(req.params.id, title);

        if (result.matchedCount === 0) {
            return res.status(404).json({ message: 'Section not found' });
        }
        res.status(201).json({ success: true, subsection });
    } catch (error) {
        next(error);
    }
};

// Update Subsection
exports.updateSubsection = async (req, res, next) => {
    try {
        const { title } = req.body;
        const { sectionId, subsectionId } = req.params;

        const result = await Section.updateSubsection(sectionId, subsectionId, title);
        if (result.matchedCount === 0) {
            return res.status(404).json({ message: 'Section or Subsection not found' });
        }
        res.json({ success: true, message: 'Subsection updated successfully' });
    } catch (error) {
        next(error);
    }
};

// Delete Subsection
exports.deleteSubsection = async (req, res, next) => {
    try {
        const { sectionId, subsectionId } = req.params;
        const result = await Section.deleteSubsection(sectionId, subsectionId);

        if (result.matchedCount === 0) {
            return res.status(404).json({ message: 'Section not found' });
        }
        res.json({ success: true, message: 'Subsection deleted successfully' });
    } catch (error) {
        next(error);
    }
};

// Add Problem to Subsection
exports.addProblemToSubsection = async (req, res, next) => {
    try {
        const { sectionId, subsectionId } = req.params;
        const { problemId } = req.body;

        if (!problemId) {
            return res.status(400).json({ message: 'Problem ID is required' });
        }

        // Verify problem exists
        const problem = await Problem.findById(problemId);
        if (!problem) {
            return res.status(404).json({ message: 'Problem not found' });
        }

        const result = await Section.addProblemToSubsection(sectionId, subsectionId, problemId);

        if (result.matchedCount === 0) {
            return res.status(404).json({ message: 'Section or Subsection not found' });
        }

        if (result.modifiedCount === 0) {
            return res.status(400).json({ message: 'Problem might already exist in this subsection' });
        }

        res.json({ success: true, message: 'Problem added to subsection' });
    } catch (error) {
        next(error);
    }
};

// Remove Problem from Subsection
exports.removeProblemFromSubsection = async (req, res, next) => {
    try {
        const { sectionId, subsectionId, problemId } = req.params;

        const result = await Section.removeProblemFromSubsection(sectionId, subsectionId, problemId);

        if (result.matchedCount === 0) {
            return res.status(404).json({ message: 'Section or Subsection not found' });
        }

        res.json({ success: true, message: 'Problem removed from subsection' });
    } catch (error) {
        next(error);
    }
};
