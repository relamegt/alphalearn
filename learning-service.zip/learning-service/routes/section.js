const express = require('express');
const router = express.Router();
const {
    createSection,
    getAllSections,
    getSectionById,
    updateSection,
    deleteSection,
    addSubsection,
    updateSubsection,
    deleteSubsection,
    addProblemToSubsection,
    removeProblemFromSubsection
} = require('../controllers/sectionController');
const { verifyToken } = require('../middleware/auth');
const { adminOnly } = require('../middleware/roleGuard');

// All routes require authentication and admin role
router.use(verifyToken);
router.use(adminOnly);

router.route('/')
    .get(getAllSections)
    .post(createSection);

router.route('/:id')
    .get(getSectionById)
    .put(updateSection)
    .delete(deleteSection);

router.route('/:id/subsections')
    .post(addSubsection);

router.route('/:sectionId/subsections/:subsectionId')
    .put(updateSubsection)
    .delete(deleteSubsection);

router.route('/:sectionId/subsections/:subsectionId/problems')
    .post(addProblemToSubsection);

router.route('/:sectionId/subsections/:subsectionId/problems/:problemId')
    .delete(removeProblemFromSubsection);

module.exports = router;
