const { ObjectId } = require('bson');
const { collections } = require('../config/astra');

class Section {
    // Create new section
    static async create(sectionData) {
        const section = {
            _id: new ObjectId(),
            title: sectionData.title,
            subsections: [], // Array of objects { _id: ObjectId, title: String, problemIds: [ObjectId] }
            createdAt: new Date(),
            updatedAt: new Date()
        };

        const result = await collections.sections.insertOne(section);
        return { ...section, _id: result.insertedId };
    }

    // Find all sections
    static async findAll() {
        return await collections.sections.find({}).sort({ title: 1 }).toArray();
    }

    // Find section by ID
    static async findById(sectionId) {
        return await collections.sections.findOne({ _id: new ObjectId(sectionId) });
    }

    // Update section (title)
    static async update(sectionId, updateData) {
        return await collections.sections.updateOne(
            { _id: new ObjectId(sectionId) },
            { 
                $set: { 
                    ...updateData,
                    updatedAt: new Date()
                } 
            }
        );
    }

    // Delete section
    static async delete(sectionId) {
        return await collections.sections.deleteOne({ _id: new ObjectId(sectionId) });
    }

    // Add subsection
    static async addSubsection(sectionId, title) {
        const subsection = {
            _id: new ObjectId(),
            title: title,
            problemIds: []
        };

        const result = await collections.sections.updateOne(
            { _id: new ObjectId(sectionId) },
            { 
                $push: { subsections: subsection },
                $set: { updatedAt: new Date() }
            }
        );
        return { result, subsection };
    }

    // Update subsection title
    static async updateSubsection(sectionId, subsectionId, title) {
        return await collections.sections.updateOne(
            { _id: new ObjectId(sectionId), "subsections._id": new ObjectId(subsectionId) },
            { 
                $set: { 
                    "subsections.$.title": title,
                    updatedAt: new Date()
                } 
            }
        );
    }

    // Delete subsection
    static async deleteSubsection(sectionId, subsectionId) {
        return await collections.sections.updateOne(
            { _id: new ObjectId(sectionId) },
            { 
                $pull: { subsections: { _id: new ObjectId(subsectionId) } },
                $set: { updatedAt: new Date() }
            }
        );
    }

    // Add problem to subsection
    static async addProblemToSubsection(sectionId, subsectionId, problemId) {
        // Check if problem is already in the subsection
        // Note: $addToSet ensures uniqueness
        return await collections.sections.updateOne(
            { _id: new ObjectId(sectionId), "subsections._id": new ObjectId(subsectionId) },
            { 
                $addToSet: { "subsections.$.problemIds": new ObjectId(problemId) },
                $set: { updatedAt: new Date() }
            }
        );
    }

    // Remove problem from subsection
    static async removeProblemFromSubsection(sectionId, subsectionId, problemId) {
        return await collections.sections.updateOne(
            { _id: new ObjectId(sectionId), "subsections._id": new ObjectId(subsectionId) },
            { 
                $pull: { "subsections.$.problemIds": new ObjectId(problemId) },
                $set: { updatedAt: new Date() }
            }
        );
    }
}

module.exports = Section;
